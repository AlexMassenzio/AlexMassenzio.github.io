﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using Newtonsoft.Json;

public class BeatmapSetup : MonoBehaviour {

    public string beatmapName;

    public BeatmapData beatmapData = null;

    // Initialization
    void Start ()
    {
        LoadBeatmapData();
        SendBeatmapData();
        AssignInstruments();
	}
	
    public static T ReadFromJsonFile<T>(string fileName) where T : new()
    {
        TextAsset fileContents = Resources.Load(fileName) as TextAsset;
        Debug.Log(fileContents);
        return JsonConvert.DeserializeObject<T>(fileContents.text);
    }

    public bool LoadBeatmapData()
    {
        beatmapData = ReadFromJsonFile<BeatmapData>(beatmapName);
        return true;
    }

    public void SendBeatmapData()
    {
        Debug.Log("Loading beatmap: " + beatmapData.songName);
        foreach (Instrument i in beatmapData.instruments)
        {
            Debug.Log(i.name + "| Lanes: " + i.lanes.Count.ToString() + "| Lane 0: " + i.lanes[0].ToString());
        }
    }

    public void AssignInstruments()
    {
        GameObject[] instrumentObjects = GameObject.FindGameObjectsWithTag("Instrument");

        foreach(Instrument instrument in beatmapData.instruments)
        {
            for (int i = 0; i < instrumentObjects.Length; i++)
            {
                if(instrument.name == instrumentObjects[i].name)
                {
                    instrumentObjects[i].GetComponent<InstrumentController>().LoadLanes(instrument);
                }
            }
        }
    }
}

[Serializable]
public class BeatmapData
{
    public List<Instrument> instruments;
    public string songName;
    public int bpm;
}

[Serializable]
public class Instrument
{
    public string name;
    public List<Lane> lanes;
    public List<float> soloTimes;
}

[Serializable]
public class Lane
{
    public List<float> notes;
    public string input;
}