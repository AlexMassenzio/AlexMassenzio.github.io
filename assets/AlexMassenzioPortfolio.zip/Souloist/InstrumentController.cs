﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstrumentController : MonoBehaviour {

    public GameObject genericLane; //Visual object of the lane
	public GameObject genericNote; //Visual object of the note
    public GameObject[] genericNotes; //An array of note-sets. Used to show control options for 
    public List<LaneController> highway;
    public Queue<float> soloTimes;
    public GameObject soloIndicator;

    private Conductor conductor;

    public bool isInteracting = false;

    [Range(0f,1f)]
    public float approachRate = 1f;
    [Range(0f, 100f)]
    public float soulBar = 100f; //Efficency mechanic
    public float soulDrain = 25f;

	//Initialization
	void Start () {
        this.GetComponent<SpriteRenderer>().sortingOrder = -1 * (int)(this.transform.position.y * 1000);
        conductor = GameObject.Find("Conductor").GetComponent<Conductor>();
    }
	
	// Update is called once per frame
	void Update () {
        soulBar = Mathf.Max(soulBar - (Time.deltaTime * soulDrain * (soloIndicator.activeInHierarchy ? 3 : 1) * (isInteracting ? 0 : 1)), 0);
        this.GetComponent<Animator>().SetBool("Active", soulBar > 0); //Cue animation when our soulbar is not empty

        try
        {
            if (soloTimes.Count > 0 && soloTimes.Peek() < (conductor.songPosition + conductor.beatDuration * 4))
            {
                StartCoroutine(IndicateSolo());
            }
        } catch (System.Exception e)
        {
            Debug.Log(e.Message);
        }
    }

    public void StartInteracting()
    {
        isInteracting = true;
        Debug.Log("I started interacting!");
        foreach(LaneController l in highway)
        {
            l.ShowLanes();
        }
    }

    public void StopInteracting()
    {
        isInteracting = false;
        Debug.Log("No more interacting.");
        foreach (LaneController l in highway)
        {
            l.HideLanes();
        }
    }

    public void receiveInput(string input)
    {
        foreach (LaneController l in highway)
        {
            l.receiveInput(input);
        }
    }

	/// <summary>
	/// Instantiates the Lane(s) into the instrument.
	/// </summary>
	/// <param name="instrument">The Instrument data to load</param>
	public void LoadLanes(Instrument instrument)
    {
        for(int i = 0; i < instrument.lanes.Count; i++)
        {
            GameObject createdLane = Instantiate(genericLane, transform);

            createdLane.transform.position = new Vector2(transform.position.x + createdLane.GetComponent<SpriteRenderer>().bounds.size.x * i, createdLane.transform.position.y + 0.75f);

			LaneController lc = createdLane.GetComponent<LaneController>();
            highway.Add(lc);
            lc.LoadNotes(instrument.lanes[i]);

            if (genericNotes.Length > i - 1)
            {
                lc.localNote = genericNotes[i];
                lc.input = genericNotes[i].name.Substring(5).ToLower(); //pull from name of note object
            }
            else
            {
                lc.localNote = genericNote;
            }
        }

        soloTimes = new Queue<float>();
        foreach(float solo in instrument.soloTimes)
        {
            Debug.Log(gameObject.name + " enqueueing solo time " + solo.ToString());
            soloTimes.Enqueue(solo);
        }

        foreach (LaneController l in highway)
        {
            l.HideLanes();
        }

    }

    IEnumerator IndicateSolo()
    {
        float soloTime = soloTimes.Dequeue();
        soloIndicator.SetActive(true);
        while (soloTime > conductor.songPosition)
        {
            yield return null;
        }
        soloIndicator.SetActive(false);
    }
}
