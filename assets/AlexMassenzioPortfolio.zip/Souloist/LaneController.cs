﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LaneController : MonoBehaviour {

    public GameObject noteStart, noteEnd;

    private Conductor conductor;
    
    private float instrumentApproachRate;

    public string input;

    public GameObject localNote;
    public Text hitStatus;

    public Queue<float> queuedNotes;
    public Queue<float> sentNotes;


	// Initialization
	void Start () {

        conductor = GameObject.Find("Conductor").GetComponent<Conductor>();
        InstrumentController ic = transform.parent.GetComponent<InstrumentController>();
        instrumentApproachRate = ic.approachRate / conductor.pitch;

        noteStart = transform.GetChild(0).gameObject;
        noteEnd = transform.GetChild(1).gameObject;
    }

    public void receiveInput(string givenInput)
    {
        if (givenInput == input && sentNotes.Count > 0)
        {
            Debug.Log("Input was accepted by lane.");
            if (sentNotes.Peek() < (conductor.songPosition - conductor.hitWindow / 2))
            {
                Debug.Log("Late!");
                hitStatus.text = "Late!";
                hitStatus.color = Color.red;
                sentNotes.Dequeue();
            }
            else
            {
                float noteToCheck = sentNotes.Peek();
                float hitDelta = noteToCheck - conductor.songPosition + conductor.inputLag;
                Debug.Log(hitDelta + " vs " + (conductor.hitWindow / 2));
                if (Mathf.Abs(hitDelta) < (conductor.hitWindow / 2f))
                {
                    Debug.Log("Hit!");
                    hitStatus.text = "Hit!";
                    hitStatus.color = Color.green;
                    sentNotes.Dequeue();

                    this.transform.parent.GetComponent<InstrumentController>().soulBar += 10;

					if (this.transform.parent.GetComponent<InstrumentController>().soulBar > 100)
					{
						this.transform.parent.GetComponent<InstrumentController>().soulBar = 100;
					}
                }
                else if (Mathf.Abs(hitDelta) < conductor.hitWindow)
                {
                    Debug.Log("Miss!");
                    hitStatus.text = "Early!";
                    hitStatus.color = Color.red;
                    sentNotes.Dequeue();
                }
            }
        }
		else if (givenInput != input)
        {
            Debug.Log("Lane " + input + " rejected givenInput: " + givenInput);
        }
    }

    public void HideLanes()
    {
        this.gameObject.GetComponent<SpriteRenderer>().sortingLayerName = "Hidden";
    }

    public void ShowLanes()
    {
        this.gameObject.GetComponent<SpriteRenderer>().sortingLayerName = "Lane";
    }
	
	// Update is called once per frame
	void Update ()
    {
        instrumentApproachRate = transform.parent.GetComponent<InstrumentController>().approachRate / conductor.pitch;
        
        if (queuedNotes.Count > 0 && queuedNotes.Peek() < (conductor.songPosition + instrumentApproachRate))
        {
            GameObject noteToSend = Instantiate(localNote, noteStart.transform);
            noteToSend.transform.position = noteStart.transform.position;

            var seq = LeanTween.sequence();
            seq.append(LeanTween.move(noteToSend, noteEnd.transform.position, instrumentApproachRate));

            sentNotes.Enqueue(queuedNotes.Dequeue());
            noteToSend.GetComponent<NoteController>().timeToLive = (float)(instrumentApproachRate + (instrumentApproachRate * 0.1));
            noteToSend.GetComponent<NoteController>().owningLane = this.gameObject.GetComponent<LaneController>();
        }

        if (sentNotes.Count > 0 && sentNotes.Peek() < (conductor.songPosition - conductor.hitWindow / 2))
        {
            Debug.Log("Late!");
            hitStatus.text = "Late!";
            hitStatus.color = Color.red;
            sentNotes.Dequeue();
        } 
	}

	/// <summary>
	/// Loads all relevant notes into the LaneControllers queue.
	/// </summary>
	/// <param name="lane">The Lane data to load</param>
    public void LoadNotes(Lane lane)
    {
        queuedNotes = new Queue<float>();
        sentNotes = new Queue<float>();
        //input = lane.input;
        foreach (float note in lane.notes)
        {
            queuedNotes.Enqueue(note);
        }
    }
}
