Alex Massenzio
19 Mill Creek Road
Sparta NJ, 07871
(862)-266-1241
contact@alexmassenzio.com

For a showcase of finished projects, visit: http://www.alexmassenzio.com/projects

==========Portfolio Guide==========

==Directory Structure==
 - Within this directory, each folder represents a separate project I have worked on.
 - Each one of these project folders will have select files showingcasing how I created a specific mechanic or feature.
 - The contents of each project folder are NOT a final, buildable project.

==Projects==

 1)Souloist (October, 2017), a co-op rhythm game created in 48 hours for a local game jam. (Made in Unity)

   + These 4 C# files included represent the backbone of the rhythm game's metronome, as well as the beatmap loading system.

   + 'Conductor.cs'
     - Takes in an audio file, as well as other information including bpm and pitch.
     - While the song is playing, the script uses the position of the song to calculate the current beat and the crotchet (how much time has passed within the beat).
     - Any mechanic or system that needs to sync with the current song will reference the script.

   + 'BeatmapSetup.cs'
     - This file's input is a beatmap (A file containing data about every note to be played for a given song)
     - The script takes the beatmap data, serializes it into a C# class, and assigns the contents of said class to a list of 'instruments'.

   + 'InstrumentController.cs'
     - In the game, a player can walk up to a series of instruments and play along with the song. This script enables that action.
     - The LoadLanes function creates the desired amount of note lanes for the instrument that the beatmap data specifies.

   + 'LaneController.cs'
     - Each note lane in the game has this lane controller script attached to it.
     - The script takes in a queue of timestamps (floats) in which to create notes at.
     - The script also decides if the note is early, on-time, or late.

   + These files and the code within them were created by me, but the project as a whole was created by 3 people (me included) within 48 hours.


 2)Don't Let Go Bro (September 2017 - Ongoing), A puzzle game for Android and IOS. (Unity)

   + Currently being developed as a Senior Design project with 4 other students.

   + 'CameraFollow.cs'
     - Each level contains multiple 'Bro' characters that need to be controlled to reach the goal.
     - The script takes in a list of bros in which the camera needs to scale and move to fit them all.
     - Smoothing is applied to the camera to make the game easier to watch.

   + 'StateManager.cs'
     - A simple state manager using enum.
     - Allows for other scripts to change the game state, and tell whether or not it is the first frame since the state switched (used for one-time events to be called).