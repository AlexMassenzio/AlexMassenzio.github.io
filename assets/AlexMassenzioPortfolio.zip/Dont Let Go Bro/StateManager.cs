﻿/* 
 * Copyright (C) 2017 Alex Massenzio - All Rights Reserved
 * A scipt that manages the game's various states.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StateManager : MonoBehaviour {

	public bool firstFrameInState;

	public enum GameState { Init, Playing, Complete}; //Add states as needed
	private GameState levelState;
	public GameState LevelState
	{
		get
		{
			return levelState;
		}
		set
		{
            if (levelState != value)
            {
                firstFrameInState = true;
            }
			levelState = value;
		}
	}

	//Initialization
	void Awake () {
		levelState = GameState.Init;
	}
	
	// Update is called once per frame
	void Update () {

		switch(levelState)
		{
			case GameState.Init:
				if(firstFrameInState)
				{
					Debug.Log("Entered state: " + levelState);
					firstFrameInState = false;
				}
				else
				{

				}
				break;

			case GameState.Playing:
				if (firstFrameInState)
				{
					Debug.Log("Entered state: " + levelState);
					firstFrameInState = false;
				}
				else
				{

				}
				break;

            case GameState.Complete:
                if (firstFrameInState)
                {
                    Debug.Log("Entered state: " + levelState);
                    if (SceneManager.GetActiveScene().buildIndex + 1 < SceneManager.sceneCountInBuildSettings)
                        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                    else
                        SceneManager.LoadScene(0);
                    firstFrameInState = false;
                }
                else
                {

                }
                break;

            default:
				Debug.LogError("The StateManager has entered a non-defined state.", this);
				break;
		}
	}
}
