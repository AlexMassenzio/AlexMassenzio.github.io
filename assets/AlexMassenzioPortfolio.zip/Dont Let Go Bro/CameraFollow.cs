﻿/* 
 * Copyright (C) 2017 Alex Massenzio - All Rights Reserved
 * A scipt that allows the camera to find and follow all 'bros' in the scene
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

	public float smoothingModifier = 5f;
	public float cameraPadding = 2f;

	private List<GameObject> bros;
	private Vector3 focus; //The final location the camera should track.


	private Vector2 aspectRatio;

	void Start ()
	{
		bros = new List<GameObject>(GameObject.FindGameObjectsWithTag("Bro"));
		aspectRatio = AspectRatio.GetAspectRatio(Screen.width, Screen.height);
	}
	
	void Update ()
	{

		float minX = bros[0].transform.position.x;
		float maxX = bros[0].transform.position.x;
		float minY = bros[0].transform.position.y;
		float maxY = bros[0].transform.position.y;

		focus = Vector3.zero;

		//get the smallest and largest x and y values for all bros in the scene.
		foreach (GameObject bro in bros)
		{
			if(bro.transform.position.x < minX)
			{
				minX = bro.transform.position.x;
			}
			else if (bro.transform.position.x > maxX)
			{
				maxX = bro.transform.position.x;
			}

			if (bro.transform.position.y < minY)
			{
				minY = bro.transform.position.y;
			}
			else if (bro.transform.position.y > maxY)
			{
				maxY = bro.transform.position.y;
			}
		}

		float distanceX = maxX - minX;
		float distanceY = maxY - minY;

		if (distanceY > distanceX)
		{
			//Smoothing modifier applied by scaling to [smoothingModifier]% of the desired size every second.
			Camera.main.orthographicSize += ((distanceY * 0.5f + cameraPadding) - Camera.main.orthographicSize) * Time.deltaTime * smoothingModifier;
		}
		else
		{
			//Smoothing modifier applied by scaling to [smoothingModifier]% of the desired size every second.
			Camera.main.orthographicSize += ((distanceX * 0.5f + cameraPadding) - Camera.main.orthographicSize) * Time.deltaTime * smoothingModifier;
		}

		focus = new Vector3(minX + maxX, minY + maxY) / 2f; //Set the focus to be the average of the bros with the furthest distance from eachother.

		focus.z = transform.position.z; // Keeps the camera from moving past objects in the scene.

		//Smoothing modifier applied by traveling [smoothingModifier]% of the distance to the target every second.
		transform.position += (focus - transform.position) * Time.deltaTime * smoothingModifier;
	}

	public void BroDied(GameObject bro)
	{
		Debug.Log ("Bro Died");
		bros.Remove (bro);
	}

	public void BroBorn(GameObject bro)
	{
		bros.Add (bro);
	}
}
