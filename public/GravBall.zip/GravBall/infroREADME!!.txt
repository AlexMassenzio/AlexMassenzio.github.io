How to play:
Get you ball to the goal by changing
the gravity of the environment. When your
ball goes through a gravity gate (see
controls) it will change the gravity!


Controls:
R = Restart

WASD + Click & Drag = Make a gravity gate!
(Example: S + Click & Drag makes a
downwards gravity gate)

Press "Play!" to begin!


Created By Alex Massenzio :D